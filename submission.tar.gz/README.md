This is a picture puzzle sliding game.  The goal is to fix the shuffled picture.  
You do this by navigating the player square with the arow keys.  Slide a tile into the empty space by pressing A.

In the menu screen, press the Start key to start the game.  While playing, press B to return the the start screen.