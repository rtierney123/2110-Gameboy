/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 path path.jpg 
 * Time-stamp: Wednesday 11/14/2018, 04:15:53
 * 
 * Image Information
 * -----------------
 * path.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PATH_H
#define PATH_H

extern const unsigned short path[38400];
#define PATH_SIZE 76800
#define PATH_LENGTH 38400
#define PATH_WIDTH 240
#define PATH_HEIGHT 160

#endif

