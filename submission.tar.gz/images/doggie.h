/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 doggie doggie.jpg 
 * Time-stamp: Thursday 11/15/2018, 05:54:00
 * 
 * Image Information
 * -----------------
 * doggie.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOGGIE_H
#define DOGGIE_H

extern const unsigned short doggie[38400];
#define DOGGIE_SIZE 76800
#define DOGGIE_LENGTH 38400
#define DOGGIE_WIDTH 240
#define DOGGIE_HEIGHT 160

#endif

