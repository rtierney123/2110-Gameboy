/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x37 dolce dolce.jpg 
 * Time-stamp: Tuesday 11/13/2018, 04:34:33
 * 
 * Image Information
 * -----------------
 * dolce.jpg 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOLCE_H
#define DOLCE_H

extern const unsigned short dolce[1850];
#define DOLCE_SIZE 3700
#define DOLCE_LENGTH 1850
#define DOLCE_WIDTH 50
#define DOLCE_HEIGHT 37

#endif

